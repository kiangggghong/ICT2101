Please add all the files in the project. 

Functions are in jquery. Add the following functions: 
1) getTotalTimeOfOverallRoadmap(type) **STUB**
2) generateOverallRoadmap(type) **STUB**
3) prioritizePackage(packageID) 

Add in the Manager_trackDrierPage. 
I commented with caps the changes that i had to made for the function to work.